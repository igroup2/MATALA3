﻿namespace SteamStore.Models
{
    public class User
    {
        int id;
        string name;
        string email;
        string password;

        static List<User> UserList = new List<User>();

        public User() { }   
        public User(int id, string name, string email, string password)
        {
            Id = id;
            Name = name;
            Email = email;
            Password = password;
        }

        public int Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public string Email { get => email; set => email = value; }
        public string Password { get => password; set => password = value; }

        public int Insert()
        {

            for (int i = 0; i < UserList.Count; i++)
            {

                if (UserList[i].Id == this.Id)
                {
                    return 0;
                }
            }

            UserList.Add(this);
            return 1;
        }

        static public List<User> Read()
        {
            return UserList;
        }



    }
}
